from apf.controller import controller

project = controller.create_project(
    title="Little Hands, Big Pictures",
    product_type="coloring_book",
    audience="To be confirmed",
    market="To be confirmed",
)
print(project.model_dump_json(indent=2))
