from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from apf.controller import controller
from apf.core.projects import Project

app = FastAPI(title="AI Publishing Factory API", version="0.1.1")
_projects: dict[str, Project] = {}

class CreateProjectRequest(BaseModel):
    title: str
    product_type: str
    audience: str | None = None
    market: str | None = None

@app.get("/health")
def health():
    return {"status": "ok", "version": "0.1.1"}

@app.post("/projects", response_model=Project)
def create_project(payload: CreateProjectRequest):
    project = controller.create_project(**payload.model_dump())
    _projects[project.id] = project
    return project

@app.get("/projects/{project_id}", response_model=Project)
def get_project(project_id: str):
    project = _projects.get(project_id)
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return project

@app.get("/product-types")
def product_types():
    from apf.core.products import ProductType
    return {"product_types": [item.value for item in ProductType]}
