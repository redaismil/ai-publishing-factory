from enum import Enum

class ProductType(str, Enum):
    COLORING_BOOK = "coloring_book"
    LEARNING_BOOK = "learning_book"
    WORKBOOK = "workbook"
    PUZZLE_BOOK = "puzzle_book"
    PLANNER = "planner"
    JOURNAL = "journal"
    PRINTABLE = "printable"
    FLASHCARDS = "flashcards"
    ACTIVITY_BOOK = "activity_book"
    EDUCATIONAL_RESOURCE = "educational_resource"
    OTHER = "other"
