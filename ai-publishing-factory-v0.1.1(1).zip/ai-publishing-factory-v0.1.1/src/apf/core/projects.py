from datetime import datetime, timezone
from enum import Enum
from uuid import uuid4
from pydantic import BaseModel, Field

class ProjectStatus(str, Enum):
    DRAFT = "draft"
    PLANNING = "planning"
    IN_PRODUCTION = "in_production"
    REVIEW = "review"
    APPROVED = "approved"
    COMPLETED = "completed"
    ON_HOLD = "on_hold"

class Project(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    title: str
    product_type: str
    audience: str | None = None
    market: str | None = None
    status: ProjectStatus = ProjectStatus.DRAFT
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict = Field(default_factory=dict)
