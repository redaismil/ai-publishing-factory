from enum import Enum
from pydantic import BaseModel

class ApprovalGate(str, Enum):
    CONCEPT = "concept"
    CONTENT = "content"
    VISUAL_SAMPLE = "visual_sample"
    QUALITY = "quality"
    FINAL_DELIVERY = "final_delivery"

class ApprovalRecord(BaseModel):
    gate: ApprovalGate
    approved: bool = False
    approved_by: str | None = None
    notes: str | None = None

REQUIRED_GATES = list(ApprovalGate)
