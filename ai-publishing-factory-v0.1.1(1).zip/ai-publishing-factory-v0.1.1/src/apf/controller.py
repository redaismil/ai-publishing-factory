from apf.core.projects import Project

class MasterController:
    def create_project(self, title: str, product_type: str, **kwargs) -> Project:
        return Project(title=title, product_type=product_type, **kwargs)

controller = MasterController()
