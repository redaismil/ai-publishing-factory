# MCP integration placeholder

The MCP server is intentionally not activated in this starter. The next implementation step is to select a supported MCP SDK version and define stable tools/resources around the controller and project service.
