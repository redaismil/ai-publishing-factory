from abc import ABC, abstractmethod
from apf.core.projects import Project

class ProductEngine(ABC):
    @abstractmethod
    def validate_brief(self, brief: dict) -> list[str]:
        raise NotImplementedError

    @abstractmethod
    def plan(self, project: Project) -> dict:
        raise NotImplementedError
