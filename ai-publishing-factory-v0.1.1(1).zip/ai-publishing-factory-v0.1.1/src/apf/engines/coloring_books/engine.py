from apf.engines.base import ProductEngine
from apf.core.projects import Project

class ColoringBookEngine(ProductEngine):
    def validate_brief(self, brief: dict) -> list[str]:
        required = ["age_range", "theme", "page_count"]
        return [f"Missing required field: {key}" for key in required if key not in brief]

    def plan(self, project: Project) -> dict:
        return {
            "project_id": project.id,
            "engine": "coloring_book",
            "status": "planned",
            "next_step": "Define page-by-page illustration concepts",
        }
