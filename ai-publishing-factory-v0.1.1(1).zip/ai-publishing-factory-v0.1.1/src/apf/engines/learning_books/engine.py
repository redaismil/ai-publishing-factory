from apf.engines.base import ProductEngine
from apf.core.projects import Project

class LearningBookEngine(ProductEngine):
    def validate_brief(self, brief: dict) -> list[str]:
        required = ["learning_objective", "age_range", "subject"]
        return [f"Missing required field: {key}" for key in required if key not in brief]

    def plan(self, project: Project) -> dict:
        return {
            "project_id": project.id,
            "engine": "learning_book",
            "status": "planned",
            "next_step": "Map learning objectives to a chapter sequence",
        }
