# AI Publishing Factory (APF)

A modular starter for planning and producing digital publishing products.

## Status
Early development scaffold. The REST API and project models are starter implementations; production storage, authentication, provider integrations, and complete production engines are not included yet.

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -e .[dev]
uvicorn apf.api.main:app --reload
```
Open http://127.0.0.1:8000/docs.

## Architecture
- `apf.controller`: orchestration entry point
- `apf.core`: product types, project state, approval gates
- `apf.engines`: product-specific engines
- `apf.api`: REST API
- `apf.mcp`: MCP integration placeholder

No external publishing action is performed. Final publishing requires explicit human approval.
