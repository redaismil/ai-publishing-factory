from apf.core.products import ProductType
from apf.core.approvals import REQUIRED_GATES, ApprovalGate
from apf.core.projects import Project, ProjectStatus

def test_product_types_include_coloring_and_learning():
    assert ProductType.COLORING_BOOK.value == "coloring_book"
    assert ProductType.LEARNING_BOOK.value == "learning_book"

def test_five_approval_gates():
    assert len(REQUIRED_GATES) == 5
    assert ApprovalGate.FINAL_DELIVERY in REQUIRED_GATES

def test_project_defaults_to_draft():
    project = Project(title="Demo", product_type="planner")
    assert project.status == ProjectStatus.DRAFT
