from fastapi.testclient import TestClient
from apf.api.main import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_create_project():
    response = client.post("/projects", json={"title": "Demo", "product_type": "planner"})
    assert response.status_code == 200
    assert response.json()["title"] == "Demo"
