# Contributing

1. Create a focused branch.
2. Add or update tests for behavior changes.
3. Run `pytest`.
4. Keep provider-specific code behind interfaces.
5. Never trigger external publishing without explicit approval.
