# Architecture

## Shared core
The shared core owns project metadata, product classification, workflow state, approvals, and reusable planning contracts.

## Engines
Each product family has an independent engine (coloring books, learning books, workbooks, puzzles, planners, journals, printables, flashcards, activity books).

## Integrations
REST API is the initial integration surface. MCP support is a placeholder until a concrete MCP SDK and tool contract are selected.

## Safety
Generating files does not authorize publishing them. External publishing requires explicit approval for the product and destination.
