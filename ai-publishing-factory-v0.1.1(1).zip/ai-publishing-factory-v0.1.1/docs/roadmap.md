# Roadmap

- [x] Initial package structure and API skeleton
- [x] Project model and approval gate model
- [ ] Persistent database repository
- [ ] Authentication and authorization
- [ ] Research and idea-generation adapters
- [ ] Content architecture and quality evaluation
- [ ] Complete product-specific engines
- [ ] MCP server implementation
- [ ] Export pipelines (PDF/EPUB/print-ready)
- [ ] Dashboard and job monitoring
