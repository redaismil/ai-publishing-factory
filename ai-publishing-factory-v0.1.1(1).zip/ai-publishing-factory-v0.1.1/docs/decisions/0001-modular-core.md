# ADR 0001: Modular core

**Status:** Accepted

Keep orchestration, shared project contracts, product engines, and integrations in separate modules. Avoid coupling core workflows to one AI provider.
