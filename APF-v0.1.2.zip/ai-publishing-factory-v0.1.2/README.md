# AI Publishing Factory (APF)

A modular, provider-agnostic foundation for planning and producing books and digital publishing products.

**Release:** 0.1.2 — starter foundation, not a production publishing system.

## What is included
- Product-type registry covering books, workbooks, planners, journals, puzzles, flashcards, printables and more.
- Shared project model and lifecycle.
- Five explicit approval gates.
- Master Controller for creating, inspecting and advancing projects.
- Starter Coloring Book and Learning Book engines.
- FastAPI REST interface.
- Optional MCP server entry point.
- Tests and architecture documentation.

## Requirements
- Python 3.11+
- Git (for uploading to GitHub)
- An AI provider is **not** required for the starter. Provider adapters can be added later.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -e ".[dev]"
uvicorn apf.api.main:app --reload
```
Open `http://127.0.0.1:8000/docs` for the API.

## Run tests
```bash
pytest
```

## Optional MCP server
```bash
pip install -e ".[mcp]"
python -m apf.mcp_server
```
The MCP adapter is optional. MCP compatibility depends on the client and transport it supports; REST remains available as a general integration path.

## Important safety / publishing rule
APF may prepare content and delivery files, but it must not publish externally without explicit approval for the specific product, destination and action. The five approval gates are enforced as workflow checkpoints, not as a claim that all production checks are automated.

## Current limitations
- In-memory storage only; projects reset when the process restarts.
- No real AI provider calls yet.
- No image generation, PDF composition, KDP upload or external publishing.
- Quality checks are placeholders and require product-specific implementation.
- MCP support is a starter adapter, not a universal connector.

## Repository
Target repository: `https://github.com/redaismil/ai-publishing-factory`
