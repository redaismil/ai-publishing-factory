# Roadmap

## v0.1.x — foundation
- [x] Product catalog and project model
- [x] Master Controller starter
- [x] Five sequential approval gates
- [x] REST API starter
- [x] Optional MCP starter
- [x] Two example product engines
- [ ] Persistent storage and migrations
- [ ] Authentication, authorization and audit log
- [ ] Background jobs and resumable workflows

## v0.2 — production planning
- [ ] Content Architect
- [ ] Product Brief validation by product family
- [ ] Research and Idea Generator interfaces
- [ ] Continuity and Recovery Manager
- [ ] Product-specific quality checklists

## v0.3 — production engines
- [ ] Workbooks, puzzles, planners, journals and flashcards
- [ ] Asset and prompt management
- [ ] Layout/export pipeline (PDF/EPUB/print-ready)

## v1.0 — controlled delivery
- [ ] Dashboard
- [ ] Provider adapters
- [ ] Human review and approval UI
- [ ] Delivery packages and publishing integrations
- [ ] Security review and deployment hardening
