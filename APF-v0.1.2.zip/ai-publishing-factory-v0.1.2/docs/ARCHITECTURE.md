# Architecture — APF 0.1.1

## Layers
1. **Master Controller** — coordinates projects, product classification, engines and approvals.
2. **Shared Core** — project model, classification, approval protocol and workflow state.
3. **Product Engines** — specialized production logic. This release implements starter outlines for Coloring Books and Learning Books; other types are registered but their engines are pending.
4. **Interfaces** — REST API and optional MCP adapter.
5. **Storage** — in-memory in this release; repository/database abstraction is a future milestone.

## Provider independence
Business logic does not call a specific AI provider. Future provider adapters should implement shared interfaces and remain replaceable.

## Approval protocol
Concept → Content → Visual Sample → Quality → Final Delivery.
An approval cannot be recorded as approved until the preceding gate is approved. Rejections and revisions are recorded explicitly by gate.

## External actions
External publishing, uploading or distribution must require a separate explicit user authorization for the specific action, asset and destination.
