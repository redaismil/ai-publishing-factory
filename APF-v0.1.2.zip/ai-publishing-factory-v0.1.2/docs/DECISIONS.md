# Architecture Decision Records

## ADR-001: Provider-agnostic core
**Decision:** Keep core workflow and product logic independent from any one AI vendor.
**Reason:** Allow multiple AI platforms and local models to integrate through adapters.

## ADR-002: REST plus optional MCP
**Decision:** Provide REST as the general integration surface and MCP as an optional adapter.
**Reason:** MCP is useful for compatible AI clients, while REST supports broader applications.

## ADR-003: Human approval gates
**Decision:** Require five sequential approval checkpoints.
**Reason:** Prevent unreviewed content or accidental external publishing.

## ADR-004: Start with in-memory storage
**Decision:** Use in-memory storage in the starter release.
**Reason:** Keep the initial scaffold easy to run. Persistent storage is a required next milestone before production use.
