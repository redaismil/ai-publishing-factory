# Contributing

- Keep product engines independent and registered through `engines/registry.py`.
- Keep provider-specific code outside `core/`.
- Add tests for workflow transitions and product engines.
- Never add API keys, passwords or tokens to commits.
- Do not implement external publishing without explicit destination-specific approval.
