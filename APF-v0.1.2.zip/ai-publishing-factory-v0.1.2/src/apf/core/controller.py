from apf.models.project import Project, ProductBrief, ApprovalGate, ApprovalDecision
from apf.core.classification import classify_product
from apf.core.approvals import record_approval, next_pending_gate
from apf.engines.registry import get_engine


class MasterController:
    def __init__(self):
        self._projects: dict[str, Project] = {}

    def create_project(self, brief: ProductBrief) -> Project:
        classification = classify_product(brief.product_type)
        project = Project(brief=brief)
        project.metadata["classification"] = classification
        self._projects[project.id] = project
        return project

    def get_project(self, project_id: str) -> Project:
        if project_id not in self._projects:
            raise KeyError(f"Project '{project_id}' not found")
        return self._projects[project_id]

    def list_projects(self) -> list[Project]:
        return list(self._projects.values())

    def approve(self, project_id: str, gate: ApprovalGate, decision: ApprovalDecision, note: str | None = None) -> Project:
        project = self.get_project(project_id)
        return record_approval(project, gate, decision, note)

    def plan_product(self, project_id: str) -> dict:
        project = self.get_project(project_id)
        engine = get_engine(project.brief.product_type)
        plan = engine.create_outline(project.brief)
        project.status = "planning"
        project.metadata["initial_plan"] = plan
        return plan

    def workflow_status(self, project_id: str) -> dict:
        project = self.get_project(project_id)
        pending = next_pending_gate(project)
        return {
            "project_id": project.id,
            "status": project.status,
            "next_approval_gate": pending.value if pending else None,
            "approvals": {gate.value: record.decision.value for gate, record in project.approvals.items()},
        }
