PRODUCT_TYPES: dict[str, dict[str, str]] = {
    "coloring_book": {"label": "Coloring Book", "engine": "coloring_books", "family": "book"},
    "learning_book": {"label": "Learning Book", "engine": "learning_books", "family": "book"},
    "workbook": {"label": "Workbook", "engine": "workbooks", "family": "interactive"},
    "puzzle_book": {"label": "Puzzle Book", "engine": "puzzles", "family": "activity"},
    "planner": {"label": "Planner", "engine": "planners", "family": "organizational"},
    "journal": {"label": "Journal", "engine": "journals", "family": "organizational"},
    "printable": {"label": "Printable", "engine": "printables", "family": "downloadable"},
    "flashcards": {"label": "Flashcards", "engine": "flashcards", "family": "learning"},
    "activity_book": {"label": "Activity Book", "engine": "activity_books", "family": "activity"},
    "educational_resource": {"label": "Educational Resource", "engine": "education", "family": "learning"},
}


def classify_product(product_type: str) -> dict[str, str]:
    key = product_type.strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {"coloring_books": "coloring_book", "learning_books": "learning_book", "workbooks": "workbook", "puzzle_books": "puzzle_book", "planners": "planner", "journals": "journal", "printables": "printable", "activity_books": "activity_book"}
    key = aliases.get(key, key)
    if key not in PRODUCT_TYPES:
        raise ValueError(f"Unsupported product_type '{product_type}'. Available: {', '.join(PRODUCT_TYPES)}")
    return {"key": key, **PRODUCT_TYPES[key]}


def list_product_types() -> list[dict[str, str]]:
    return [{"key": key, **value} for key, value in PRODUCT_TYPES.items()]
