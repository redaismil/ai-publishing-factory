from datetime import datetime, timezone
from apf.models.project import Project, ApprovalGate, ApprovalDecision, ApprovalRecord

GATE_ORDER = [
    ApprovalGate.CONCEPT,
    ApprovalGate.CONTENT,
    ApprovalGate.VISUAL_SAMPLE,
    ApprovalGate.QUALITY,
    ApprovalGate.FINAL_DELIVERY,
]


def record_approval(project: Project, gate: ApprovalGate, decision: ApprovalDecision, note: str | None = None) -> Project:
    index = GATE_ORDER.index(gate)
    if decision == ApprovalDecision.APPROVED and index > 0:
        previous = GATE_ORDER[index - 1]
        if project.approvals[previous].decision != ApprovalDecision.APPROVED:
            raise ValueError(f"Cannot approve {gate.value} before {previous.value} is approved")
    project.approvals[gate] = ApprovalRecord(
        gate=gate, decision=decision, note=note,
        decided_at=datetime.now(timezone.utc)
    )
    # A downstream approval cannot remain valid after an earlier gate is
    # rejected or returned to pending. Reset all later gates to pending.
    if decision != ApprovalDecision.APPROVED:
        for downstream_gate in GATE_ORDER[index + 1:]:
            project.approvals[downstream_gate] = ApprovalRecord(gate=downstream_gate)
    project.updated_at = datetime.now(timezone.utc)
    return project


def next_pending_gate(project: Project) -> ApprovalGate | None:
    for gate in GATE_ORDER:
        if project.approvals[gate].decision != ApprovalDecision.APPROVED:
            return gate
    return None
