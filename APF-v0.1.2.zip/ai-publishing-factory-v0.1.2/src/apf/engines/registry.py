from apf.engines.coloring_books import ColoringBookEngine
from apf.engines.learning_books import LearningBookEngine

_ENGINE_BY_TYPE = {
    "coloring_book": ColoringBookEngine(),
    "learning_book": LearningBookEngine(),
}


def get_engine(product_type: str):
    key = product_type.strip().lower().replace("-", "_").replace(" ", "_")
    if key not in _ENGINE_BY_TYPE:
        raise NotImplementedError(
            f"No production engine is implemented yet for '{key}'. "
            "The product type is recognized, but its specialized engine is pending."
        )
    return _ENGINE_BY_TYPE[key]
