from abc import ABC, abstractmethod
from apf.models.project import ProductBrief


class ProductEngine(ABC):
    product_types: tuple[str, ...] = ()

    @abstractmethod
    def create_outline(self, brief: ProductBrief) -> dict:
        raise NotImplementedError
