from apf.engines.base import ProductEngine
from apf.models.project import ProductBrief


class LearningBookEngine(ProductEngine):
    product_types = ("learning_book",)

    def create_outline(self, brief: ProductBrief) -> dict:
        return {
            "product_type": "learning_book",
            "title": brief.title,
            "audience": brief.audience,
            "sections": [
                {"name": "Learning Objectives", "items": ["Objectives to be defined"]},
                {"name": "Lessons", "items": ["Lesson sequence to be designed"]},
                {"name": "Practice", "items": ["Guided activities", "Review"]},
                {"name": "Assessment", "items": ["Knowledge check"]},
            ],
            "production_notes": ["Validate reading level, factual accuracy and accessibility."],
        }
