from apf.engines.base import ProductEngine
from apf.models.project import ProductBrief


class ColoringBookEngine(ProductEngine):
    product_types = ("coloring_book",)

    def create_outline(self, brief: ProductBrief) -> dict:
        return {
            "product_type": "coloring_book",
            "title": brief.title,
            "audience": brief.audience,
            "sections": [
                {"name": "Front Matter", "items": ["Title Page", "Copyright / Credits", "How to Use"]},
                {"name": "Coloring Pages", "items": ["Page concepts to be defined after content approval"]},
                {"name": "Back Matter", "items": ["About this book", "Closing page"]},
            ],
            "production_notes": ["Confirm trim size, bleed, page count and age range before layout."],
        }
