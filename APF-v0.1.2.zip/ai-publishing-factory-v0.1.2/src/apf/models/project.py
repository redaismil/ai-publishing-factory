from datetime import datetime, timezone
from enum import Enum
from uuid import uuid4
from pydantic import BaseModel, Field


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class ProjectStatus(str, Enum):
    DRAFT = "draft"
    PLANNING = "planning"
    IN_PRODUCTION = "in_production"
    REVIEW = "review"
    APPROVED = "approved"
    DELIVERED = "delivered"
    ARCHIVED = "archived"


class ApprovalGate(str, Enum):
    CONCEPT = "concept"
    CONTENT = "content"
    VISUAL_SAMPLE = "visual_sample"
    QUALITY = "quality"
    FINAL_DELIVERY = "final_delivery"


class ApprovalDecision(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class ApprovalRecord(BaseModel):
    gate: ApprovalGate
    decision: ApprovalDecision = ApprovalDecision.PENDING
    note: str | None = None
    decided_at: datetime | None = None


class ProductBrief(BaseModel):
    title: str
    product_type: str
    audience: str | None = None
    language: str = "en"
    market: str | None = None
    format: str | None = None
    goals: list[str] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)


class Project(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    brief: ProductBrief
    status: ProjectStatus = ProjectStatus.DRAFT
    current_stage: str = "concept"
    approvals: dict[ApprovalGate, ApprovalRecord] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)
    metadata: dict = Field(default_factory=dict)

    def model_post_init(self, __context) -> None:
        for gate in ApprovalGate:
            self.approvals.setdefault(gate, ApprovalRecord(gate=gate))
