from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from apf.core.controller import MasterController
from apf.core.classification import list_product_types
from apf.models.project import ProductBrief, ApprovalGate, ApprovalDecision

app = FastAPI(title="AI Publishing Factory API", version="0.1.2",
              description="Modular publishing workflow API. Starter release with in-memory storage.")
controller = MasterController()


class ApprovalRequest(BaseModel):
    gate: ApprovalGate
    decision: ApprovalDecision
    note: str | None = None


@app.get("/health")
def health():
    return {"status": "ok", "service": "ai-publishing-factory", "version": "0.1.2"}


@app.get("/product-types")
def product_types():
    return list_product_types()


@app.post("/projects", status_code=201)
def create_project(brief: ProductBrief):
    try:
        return controller.create_project(brief)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/projects")
def list_projects():
    return controller.list_projects()


@app.get("/projects/{project_id}")
def get_project(project_id: str):
    try:
        return controller.get_project(project_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@app.post("/projects/{project_id}/plan")
def plan_project(project_id: str):
    try:
        return controller.plan_product(project_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except (ValueError, NotImplementedError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/projects/{project_id}/approvals")
def approve_project(project_id: str, request: ApprovalRequest):
    try:
        return controller.approve(project_id, request.gate, request.decision, request.note)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@app.get("/projects/{project_id}/workflow")
def workflow_status(project_id: str):
    try:
        return controller.workflow_status(project_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
