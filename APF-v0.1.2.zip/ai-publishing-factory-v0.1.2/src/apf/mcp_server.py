"""Optional MCP adapter. Install with: pip install -e '.[mcp]'"""
from apf.core.controller import MasterController
from apf.models.project import ProductBrief

def main():
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:
        raise SystemExit("MCP extra is not installed. Run: pip install -e '.[mcp]'") from exc

    mcp = FastMCP("AI Publishing Factory")
    controller = MasterController()

    @mcp.tool()
    def list_supported_product_types() -> list[dict]:
        from apf.core.classification import list_product_types
        return list_product_types()

    @mcp.tool()
    def create_publishing_project(title: str, product_type: str, audience: str = "", language: str = "en") -> dict:
        brief = ProductBrief(title=title, product_type=product_type, audience=audience or None, language=language)
        return controller.create_project(brief).model_dump(mode="json")

    @mcp.tool()
    def get_publishing_project(project_id: str) -> dict:
        return controller.get_project(project_id).model_dump(mode="json")

    mcp.run()

if __name__ == "__main__":
    main()
