import pytest
from apf.core.classification import classify_product, list_product_types

def test_known_product_type():
    assert classify_product("Coloring Books")["key"] == "coloring_book"

def test_unknown_product_type():
    with pytest.raises(ValueError):
        classify_product("unknown_magic_product")

def test_catalog_is_broad():
    assert len(list_product_types()) >= 10
