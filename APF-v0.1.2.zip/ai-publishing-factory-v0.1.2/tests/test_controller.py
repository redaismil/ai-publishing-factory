from apf.core.controller import MasterController
from apf.models.project import ProductBrief

def test_create_and_plan_coloring_project():
    controller = MasterController()
    project = controller.create_project(ProductBrief(title="Tiny Shapes", product_type="coloring_book"))
    plan = controller.plan_product(project.id)
    assert plan["product_type"] == "coloring_book"
    assert controller.get_project(project.id).metadata["initial_plan"] == plan
