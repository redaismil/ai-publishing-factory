import pytest
from apf.models.project import Project, ProductBrief, ApprovalGate, ApprovalDecision
from apf.core.approvals import record_approval

def test_gates_must_be_approved_in_order():
    project = Project(brief=ProductBrief(title="Demo", product_type="coloring_book"))
    with pytest.raises(ValueError):
        record_approval(project, ApprovalGate.CONTENT, ApprovalDecision.APPROVED)
    record_approval(project, ApprovalGate.CONCEPT, ApprovalDecision.APPROVED)
    record_approval(project, ApprovalGate.CONTENT, ApprovalDecision.APPROVED)


def test_rejecting_earlier_gate_resets_downstream_approvals():
    from apf.models.project import ProductBrief, Project, ApprovalGate, ApprovalDecision
    from apf.core.approvals import record_approval

    project = Project(brief=ProductBrief(title="Test", product_type="coloring_book"))
    record_approval(project, ApprovalGate.CONCEPT, ApprovalDecision.APPROVED)
    record_approval(project, ApprovalGate.CONTENT, ApprovalDecision.APPROVED)
    record_approval(project, ApprovalGate.CONCEPT, ApprovalDecision.REJECTED, "Revise concept")

    assert project.approvals[ApprovalGate.CONCEPT].decision == ApprovalDecision.REJECTED
    assert project.approvals[ApprovalGate.CONTENT].decision == ApprovalDecision.PENDING
    assert project.approvals[ApprovalGate.VISUAL_SAMPLE].decision == ApprovalDecision.PENDING
