# AI Publishing Factory v0.1.2

## Changes
- Rebased the release on the earlier 0.1.1 source archive whose five existing tests passed.
- Updated package and API version metadata to 0.1.2.
- Removed generated Python bytecode and pytest cache files from the release contents.
- Added a GitHub Actions workflow to compile Python sources and run pytest on pushes, pull requests, and manual dispatch.
- Fixed approval workflow consistency: rejecting or reopening an earlier approval gate resets all downstream gates to pending.
- Added a regression test for downstream approval reset.

## Verification performed in the build environment
- Python compile check: passed.
- Pytest: 6 passed.
- FastAPI smoke test: health, product types, project creation, outline planning, and workflow status passed.

## Known limitations
- Project state is in-memory and is lost when the process restarts.
- Only coloring-book and learning-book outline engines are implemented; other categories are classification entries, not finished engines.
- Authentication, persistent database storage, production deployment, and full publishing/export workflows are not implemented.
- MCP adapter is optional and has not been tested against a live external MCP client in this release.
